#include <config.h>
#define _GL_SYS_SOCKET_INLINE _GL_EXTERN_INLINE
#include "sys/socket.h"
